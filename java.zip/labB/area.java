package shape;
public interface area
{
	void getarea();

}