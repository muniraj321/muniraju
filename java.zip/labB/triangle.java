package shape;
public class triangle implements area 
{
	int b,h;
	public triangle(int x, int y)
		b = x;
		h = y;
	
	public void getarea()
	{
		System.out.println(" area of triangle with height" + h + "and" + b + "is:" +0.5*b*h);
	}
}