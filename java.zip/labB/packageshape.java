

import shape.area;
import shape.circle;
import shape.triangle;
class pack
{
	public static void main(String[] args) 
	{
		area r;
		r = new circle(5);
		r.getarea();
		r = new triangle(6,7);
		r.getarea();
	}
}