import java.util.*;
class stringhandling
{
	public static void main(String args[])
	{
		String s1,s2,s,r;
		Scanner in=new Scanner(System.in);
		int ch,i;
		System.out.println("enter 2 strings");
		s1=in.next();
		s2=in.next();
		do
		{
			System.out.println("1.length");
			System.out.println("2.change caser");
			System.out.println("3.extrac char");
			System.out.println("4.compare");
			System.out.println("5.concat");
			System.out.println("6.substring");
			System.out.println("7.find and replace");
			ch=in.nextInt();
			switch(ch)
			{
				case 1:
				System.out.println("length of "+s1+"is:"+s1.length());
				break;
				
				case 2:
				System.out.println("lowercase of "+s1+"is:"+s1.toLowerCase());
				System.out.println("uppercase of "+s1+"is:"+s1.toUpperCase());
				break;
				
				case 3:
				System.out.println("enter position to extract char from s1");
				i=in.nextInt();
				System.out.println("CHARACTER of "+i+"is:"+s1.charAt(i));
				break;
				
				case 4:
				System.out.println("s1==s2"+s1==s2);
				System.out.println("s1.equals(s2)"+s1.equals(s2));
				break;
				
				case 5:
				System.out.println("s.concatenated with s2"+s1.concat(s2));
				break;
				
				case 6:
				System.out.println("enter position to extract from s1");
				i=in.nextInt();
				System.out.println("substring from "+i+"is:"+s1.substring(i));
				break;
				
				case 7:
				System.out.println("enter string to find and replace");
				s=in.next();
				r=in.next();
				System.out.println(s+"found at"+s1.indexOf(s));
				System.out.println("replaced string"+s1.replace(s,r));
				break;
				
			}
		}
		while(ch!=8);
	}
}
