class sorting
{
	public static void main(String[] args) 
	{
		try
		{
			int n=args.length;
			if(n==0)
				throw new ArrayIndexOutOfBoundsException();
			else
			{
				int a[]=new int[n];
				for(int i=0;i<n;i++)
					a[i]=Integer.parseInt(args[i]);
				System.out.println("before sorting");
				for(int i=0;i<n;i++)
					System.out.print(" "+a[i]);
				bubbleSort(a,n);
				System.out.println("\n After  sorting");
				System.out.println("Ascending  order");
				for(int i=0;i<n;i++)
					System.out.print("  "+a[i]);
				System.out.println("\nDescending  order");
				for(int i=n-1;i>=0;i--)
					System.out.print("  "+a[i]);



			}
		}
		catch(NumberFormatException e)
		{
			System.out.println("Enter only integers - NumberFormatException");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Enter Few integers through Command line - ArrayIndexOutOfBoundsException");
		}
		
	}
	static void bubbleSort(int arr[],int length)
	{
		int temp,i,j;
		for(i=0;i<length-1;i++)
			for(j=0;j<length-i-1;j++)
				if(arr[j]>arr[j+1])
				{
					temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}

	}
	
}