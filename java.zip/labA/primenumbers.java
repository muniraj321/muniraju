import java.util.*;
class lab2
{
   public static void main(String args[])
  {
    Scanner s = new Scanner(System.in);
    int m,n,p;
    System.out.println("enter 2 integer limits");
    m=s.nextInt();
    n=s.nextInt();
    for(int i=m;i<=n;i++)
     {
        p=0;
      for(int j=2;j<=i/2;j++)
      if(i%j==0)
      {
        p=1;
       break;
       }
        if(p==0)
       System.out.println(i);
     }
   }
}