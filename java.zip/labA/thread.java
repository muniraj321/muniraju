import java.awt.*;
import java.applet.*;
/*<applet code="moving ball" height=300 width=300>
</applet> */
public class movingball extends Applet implements Runnable
{
	int x,y,dx,dy,w,h;
	thread t;
	boolean flag
	public void init()
	{
		w=getwidth();
		h=getheight();
		setbackground(color.yellow);
		x=100;
		y=10
		dx=10;
		dy=10;
	}
	public void start()
	{
		flag=true;
		t=newThread(this);
		t.start();

	}
	public void paint(Graphics g)
	g.getcolor(color.blue);
	g.filloval(x,y,50,50);
}
public void run()
{
	while(flag)
	{
		if((x+dx<=0)||(x+dx>=w))
			dx=-dx;
		if((x+dy<=0)||(y+dy>=h))
			dy=-dy;
		x+=dx;
		y+=dy;
		repaint();
		try
		{
			Thread.sleep(300);
		}
		catch(InterruptedException e)
		{ }
	}
}
public void stop()
{
	t=null;
	flag=false;
}