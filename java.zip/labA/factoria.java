class ha
{

    public static void main(String args[]) 
    {
        int num[] =new int[10];
		int fact;
		
		if (args.length == 0)
		{
			System.out.println("give arg to find factorial");
			return;
		}
		for (int i = 0; i < args.length; i++)
                
		num[i] = Integer.parseInt(args[i]);
                
		for (int i = 0; i < args.length; i++)
		{
			fact = 1;
			for(int j=1;j<=num[i];j++)
                        
			fact = fact * j;
			
                      
		
		System.out.println("factorial of" + args[i] + "is :" + fact);
             }
       }

}    
