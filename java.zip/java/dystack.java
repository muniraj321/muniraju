import java.util.*;
class dystack
{
public static void main(String args[])
{
Vector v;
int c,ch,x;
String st;
Scanner s= new Scanner(System.in);
System.out.println("Enter Initial Capacity");
c=s.nextInt();
v=new Vector(c);
do
{
System.out.println("1.push");
System.out.println("2.pop");
System.out.println("3.Display");
System.out.println("4.Exit");
ch=s.nextInt();
switch(ch)
{
case 1:
System.out.println("Enter element to push");
st=s.next();
v.addElement(st);
System.out.println(st +"pushed into stack of capacity" +v.capacity());
break;
case 2:
if(v.size()!=0)
{
System.out.println(v.lastElement() +"popped from stack of size" +v.size());
v.removeElementAt(v.size()-1);
}
else
System.out.println("Underflow");
break;
case 3:
System.out.println("Stack contents" +v);
break;
}
}
while(ch!=4);
}
}
