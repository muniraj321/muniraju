import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*
<applet code="lab 91" width=300 height=400>
</applet>
*/
public class lab91 extends applet implements KeyListener,MouseListener,MousemotionListener
{
int x=20,y=30;
String msg="";
public void init()
{
add KeyListener(this);
add MouseListener(this);
add MousemotionListener(this);
}
public void Keypressed(KeyEvent k)
{
showStatus("Key down")
int Key =K.getKeycode();
msg+=Key;
repaint();
}
public void KeyReleased(KeyEvent K)
showStatus("Key Up");
}
public void KeyTyped(Keyevent K)
{
msg+=K.getKeyChar();
repaint();
}
public void MousePressed(MouseEvent me)
{
msg="Mouse Pressed";
repaint();
}
public void MouseClicked(MouseEvent me)
msg="Mouse Clicked";
repaint();
}
public void MouseEntered(MouseEvent me)
{
msg="Mouse Entered";
repaint();
}
public void MouseReleased(MouseEvent me)
{
msg="Mouse Released";
repaint();
}
public void MouseDragged(MouseEvent me)
{
msg="Mouse Dragged";
repaint();
}
public void paint(Graphics g)
{
g.drawstring(msg,x,y);
}
}


