import java.util.*;
class StringOperations 
{
public static void main(String args[])
{
Scanner inp=new Scanner(System.in);
System.out.println("Enter two strings");
String s1=inp.next();
String s2=inp.next();
System.out.println("The strings are" +s1 +"and" +s2);
int len1=s1.length();
int len2=s2.length();
System.out.println("The length of" +s1 +"is" +len1);
System.out.println("The length of" +s2 +"is" +len2);
System.out.println("The concatenation of two strings:" +s1.concat(s2));
System.out.println("First character of" +s1 +":" +s1.charAt(0));
System.out.println("The uppercase of" +s1 +":" +s1.toUpperCase());
System.out.println("The uppercase of" +s1 +":" +s2.toLowerCase());
int i=s1.indexOf("e");
if(i!=-1)
System.out.println("The letter e occurs at position" +i +"in" +s1);
else
System.out.println("The letter e is not found in" +s1);
System.out.println("Substring of" +s1+"starting from index 2 and ending at 4:" +s1.substring(2,4));
if(i!=-1)
System.out.println("Replacing 'e' with 'o' in" +s1 +":" +s1.replace('e','o'));
else
System.out.println("Letter e not found in" +s1 +"to replace with letter o");
boolean check=s1.equals(s2);
if(check==false)
System.out.println("System and operations" + s1 + "and" + s2 + "are not same");
else
System.out.println("System and operations" + s1 + "and" + s2 + "are same");
}
}